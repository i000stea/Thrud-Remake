/**
 * 生成单文件样式预览页（v2 两分页结构）。
 */

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const cssPath = path.resolve(here, '../client/src/style.css');
const dataPath = path.resolve(here, '../server/data/progress.json');
const outPath = path.resolve(here, 'style-preview.html');

const css = readFileSync(cssPath, 'utf8');
const doc = JSON.parse(readFileSync(dataPath, 'utf8'));

const snapshot = {
  generatedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
  data: doc,
  theme: 'dark',
};

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Thrud-Remake 进度面板 · 样式预览（v2）</title>
<style>
${css}
.preview-note { border-color: var(--accent); background: rgba(76,141,255,.10); }
.style-guide { display:grid; gap:10px; background: var(--panel); border:1px solid var(--line); border-radius: var(--radius); padding:14px; margin-bottom:18px; }
.style-guide h2 { margin:0; font-size:16px; }
.guide-row { display:flex; flex-wrap:wrap; gap:10px; align-items:center; }
.guide-label { width:120px; color: var(--dim); font-size:12px; }
.toast { position: fixed; right:18px; bottom:18px; background: var(--panel-2); border:1px solid var(--accent); color: var(--text); padding:10px 14px; border-radius: var(--radius); font-size:13px; opacity:0; transition: opacity .2s; pointer-events:none; z-index: 10; }
.toast.show { opacity: 1; }
</style>
</head>
<body>
<div class="app">
  <header class="app-header">
    <div class="brand">
      <h1>Thrud-Remake · 开发进度（样式预览）</h1>
      <p class="dim">单文件静态快照 · schema v2 · 数据时间 ${doc.meta.updatedAt} · 生成于 ${snapshot.generatedAt}</p>
    </div>
    <div class="toolbar">
      <button class="btn" type="button" id="fake-theme">切到亮色（预览）</button>
      <button class="btn primary" type="button" id="fake-edit">编辑模式：开（预览）</button>
      <button class="btn" type="button" id="fake-refresh">刷新（预览）</button>
      <input class="input" placeholder="管理口令 ADMIN_TOKEN" />
      <input class="input" placeholder="编辑者名（记进 updatedBy）" />
    </div>
  </header>

  <p class="banner preview-note">
    这是<b>样式确认用的单文件预览</b>：数据是 <code>server/data/progress.json</code> 的快照、样式直接内联真实应用的
    <code>client/src/style.css</code>。因此<b>不写入任何数据</b>，点编辑控件只会提示。
  </p>

  <section class="style-guide">
    <h2>控件与状态样式一览</h2>
    <div class="guide-row"><span class="guide-label">按钮</span>
      <button class="btn primary" type="button">主要</button>
      <button class="btn" type="button">普通</button>
      <button class="btn btn-ghost" type="button">幽灵</button>
      <button class="btn btn-danger" type="button">删除</button>
    </div>
    <div class="guide-row"><span class="guide-label">输入类</span>
      <input class="input" placeholder="text 输入" />
      <input class="search" type="search" placeholder="搜索…" />
      <select class="filter"><option>下拉过滤（全部）</option><option>已完成</option></select>
      <textarea class="cell-input" rows="1" placeholder="多行备注 textarea"></textarea>
    </div>
    <div class="guide-row"><span class="guide-label">状态色</span>
      <span class="tone-ok">已完成 / 已修 / 验证通过</span>
      <span class="tone-warn">执行中 / 待验证 / 观察中</span>
      <span class="tone-danger">阻塞 / 待修 / 高</span>
      <span class="tone-muted">未开始 / 已失效</span>
    </div>
    <div class="guide-row"><span class="guide-label">标签 / 进度</span>
      <span class="tag">当前焦点</span>
      <span class="chip">任务总数 <b>${doc.tasks.length}</b></span>
      <span class="chip tone-ok">已完成 <b>${doc.tasks.filter((item) => item.status === '已完成').length}</b></span>
      <span class="chip tone-warn">执行中 <b>${doc.tasks.filter((item) => item.status === '执行中').length}</b></span>
      <span class="chip tone-muted">未开始 <b>${doc.tasks.filter((item) => item.status === '未开始').length}</b></span>
      <span class="bar" style="max-width:220px"><span class="bar-fill" style="width:${Math.round((doc.tasks.filter((item) => item.status === '已完成').length / Math.max(doc.tasks.length, 1)) * 100)}%"></span></span>
    </div>
  </section>

  <nav class="tabs" id="tabs"></nav>
  <div id="content"></div>

  <footer class="app-footer">
    预览页生成命令：<code>node preview/build-preview.mjs</code>。改样式或数据后重跑一次即可对照。
  </footer>
</div>
<div class="toast" id="toast"></div>

<script>
const SNAPSHOT = ${JSON.stringify(snapshot)};
const DATA = SNAPSHOT.data;
const state = {
  tab: 'summary',
  theme: SNAPSHOT.theme,
  createOpen: false,
  editOpen: false,
  editTitle: '',
  hideCompleted: false,
  primarySortKey: 'status',
  primarySortAsc: true,
  secondarySortKey: 'priority',
  secondarySortAsc: true,
};
const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const join = (value) => Array.isArray(value) ? value.join('、') : String(value ?? '');
const truncate = (value, max = 56) => {
  const text = join(value).replace(/\\s+/g, ' ').trim();
  return text.length > max ? text.slice(0, max) + '…' : text;
};

function toneFor(text) {
  if (!text) return '';
  if (/(已完成|已修|已提交|验证通过|验收通过|成功)/.test(text)) return 'tone-ok';
  if (/(阻塞|待修|^高$|失败|错误)/.test(text)) return 'tone-danger';
  if (/(执行中|观察中|未提交|已暂存|待验证|未验证)/.test(text)) return 'tone-warn';
  if (/(未开始|已失效|已删除)/.test(text)) return 'tone-muted';
  return '';
}

function compareText(left, right, asc) {
  const dir = asc ? 1 : -1;
  if (!left && !right) return 0;
  if (!left) return 1;
  if (!right) return -1;
  return String(left).localeCompare(String(right), 'zh-Hans-CN') * dir;
}

function compareByColumn(rowA, rowB, column, asc) {
  const left = typeof column.display === 'function' ? column.display(rowA) : join(rowA[column.key]);
  const right = typeof column.display === 'function' ? column.display(rowB) : join(rowB[column.key]);
  if (column.options && column.options.length) {
    const leftIndex = column.options.indexOf(left);
    const rightIndex = column.options.indexOf(right);
    if (leftIndex !== -1 || rightIndex !== -1) {
      const dir = asc ? 1 : -1;
      const safeLeft = leftIndex === -1 ? Number.MAX_SAFE_INTEGER : leftIndex;
      const safeRight = rightIndex === -1 ? Number.MAX_SAFE_INTEGER : rightIndex;
      if (safeLeft !== safeRight) return (safeLeft - safeRight) * dir;
    }
  }
  const closeEditButton = $('#close-edit');
  if (closeEditButton) {
    closeEditButton.onclick = () => {
      state.editOpen = false;
      renderContent();
    };
  }
  const editModal = $('#preview-edit-modal');
  if (editModal) {
    editModal.onclick = (event) => {
      if (event.target === editModal) {
        state.editOpen = false;
        renderContent();
      }
    };
  }
  if (column.numeric) return (Number(left || 0) - Number(right || 0)) * (asc ? 1 : -1);
  return compareText(left, right, asc);
}

function applySorts(rows, columns, options = {}) {
  const filtered = options.supportHideCompleted && state.hideCompleted
    ? rows.filter((row) => String(row.status ?? '') !== '已完成')
    : rows;
  const sorts = [
    state.primarySortKey ? { key: state.primarySortKey, asc: state.primarySortAsc } : null,
    state.secondarySortKey && state.secondarySortKey !== state.primarySortKey
      ? { key: state.secondarySortKey, asc: state.secondarySortAsc }
      : null,
  ].filter(Boolean);
  if (!sorts.length) return filtered.slice();
  return filtered.slice().sort((rowA, rowB) => {
    for (const sort of sorts) {
      const column = columns.find((item) => item.key === sort.key);
      if (!column) continue;
      const result = compareByColumn(rowA, rowB, column, sort.asc);
      if (result !== 0) return result;
    }
    return 0;
  });
}

function summarize(doc) {
  const byType = {};
  const byCategory = {};
  const doneCount = doc.tasks.filter((item) => item.status === '已完成').length;
  const activeCount = doc.tasks.filter((item) => item.status === '执行中').length;
  const pendingCount = doc.tasks.filter((item) => item.status === '未开始').length;
  for (const item of doc.tasks) {
    byType[item.type] = (byType[item.type] || 0) + 1;
    byCategory[item.category] = (byCategory[item.category] || 0) + 1;
  }
  return {
    tasksTotal: doc.tasks.length,
    doneCount,
    activeCount,
    pendingCount,
    blockedCount: doc.tasks.filter((item) => String(item.blockedBy || '').trim()).length,
    percent: doc.tasks.length ? Math.round(doneCount / doc.tasks.length * 100) : 0,
    byType,
    byCategory,
    pitfallsTotal: doc.pitfalls.length,
    pitfallsOpen: doc.pitfalls.filter((item) => item.status === '待修' || item.status === '观察中').length,
    workspaceOpen: doc.workspace.filter((item) => item.state !== '已提交').length,
  };
}

const SUMMARY = summarize(DATA);

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => el.classList.remove('show'), 2200);
}

function applyTheme(nextTheme) {
  state.theme = nextTheme;
  document.documentElement.dataset.theme = nextTheme;
  const button = $('#fake-theme');
  if (button) button.textContent = nextTheme === 'dark' ? '切到亮色（预览）' : '切到暗色（预览）';
}

function renderTabs() {
  $('#tabs').innerHTML = [
    { key: 'summary', label: '任务汇总', count: DATA.tasks.length },
    { key: 'details', label: '全部明细', count: DATA.tasks.length + DATA.pitfalls.length + DATA.workspace.length + DATA.commits.length },
  ].map((item) => '<button class="tab' + (state.tab === item.key ? ' active' : '') + '" data-tab="' + item.key + '">' + item.label + '<span class="tab-count">' + item.count + '</span></button>').join('');
  document.querySelectorAll('[data-tab]').forEach((button) => {
    button.onclick = () => {
      state.tab = button.dataset.tab;
      renderTabs();
      renderContent();
    };
  });
}

function summaryBlock() {
  return '<section class="summary"><div class="summary-main summary-main--single">' +
    '<div class="summary-focus"><span class="tag">当前焦点</span><strong>' + esc(DATA.meta.currentFocus) + '</strong></div>' +
    '<div class="summary-bar"><div class="bar"><div class="bar-fill" style="width:' + SUMMARY.percent + '%"></div></div><span class="bar-label">' + SUMMARY.percent + '%</span></div>' +
    '<div class="chips">' +
      '<span class="chip">任务总数 <b>' + SUMMARY.tasksTotal + '</b></span>' +
      '<span class="chip tone-ok">已完成 <b>' + SUMMARY.doneCount + '</b></span>' +
      '<span class="chip tone-warn">执行中 <b>' + SUMMARY.activeCount + '</b></span>' +
      '<span class="chip tone-muted">未开始 <b>' + SUMMARY.pendingCount + '</b></span>' +
      '<span class="chip tone-danger">阻塞 <b>' + SUMMARY.blockedCount + '</b></span>' +
      '<span class="chip">类型 新 <b>' + (SUMMARY.byType['新的需求'] || 0) + '</b> / 体 <b>' + (SUMMARY.byType['用户体验补充'] || 0) + '</b> / 修 <b>' + (SUMMARY.byType['bug修理'] || 0) + '</b></span>' +
      '<span class="chip">方向 功 <b>' + (SUMMARY.byCategory['功能实现'] || 0) + '</b> / 体 <b>' + (SUMMARY.byCategory['用户体验'] || 0) + '</b> / 美 <b>' + (SUMMARY.byCategory['美术'] || 0) + '</b> / AB <b>' + (SUMMARY.byCategory['资源与AB'] || 0) + '</b> / 工 <b>' + (SUMMARY.byCategory['工程与构建'] || 0) + '</b> / 文 <b>' + (SUMMARY.byCategory['文档'] || 0) + '</b></span>' +
      '<span class="chip">关键坑 <b>' + SUMMARY.pitfallsTotal + '</b>（待修/观察 <b>' + SUMMARY.pitfallsOpen + '</b>）</span>' +
      '<span class="chip">工作区未提交 <b>' + SUMMARY.workspaceOpen + '</b></span>' +
    '</div>' +
    '<p class="summary-meta">' + esc(DATA.meta.project) + ' · Unity ' + esc(DATA.meta.unityVersion) + ' · 更新于 ' + esc(DATA.meta.updatedAt) + '（' + esc(DATA.meta.updatedBy) + '）</p>' +
  '</div></section>';
}

function createActionBlock() {
  return '<section class="summary-actions">' +
    '<button class="btn primary" type="button" id="open-create" data-ro="1">新增任务</button>' +
    '<p class="hint">新增入口改为弹窗配置；预览页只展示样式，不会真正提交。</p>' +
  '</section>';
}

function createModal() {
  if (!state.createOpen) return '';
  return '<div class="modal-mask" id="preview-modal">' +
    '<section class="modal-card">' +
      '<header class="modal-head"><div><h2>新增任务</h2><p class="hint">填写基础 6 字段后立即写入当前任务列表。</p></div><button class="btn btn-ghost" type="button" id="close-create" data-ro="1">关闭</button></header>' +
      '<div class="task-form">' +
        '<label class="form-field form-field--wide"><span>任务</span><input class="input" data-ro="1" placeholder="任务名（必填）" /></label>' +
        '<label class="form-field form-field--wide"><span>描述</span><textarea class="cell-input" data-ro="1" rows="3" placeholder="说明 / 验收要点"></textarea></label>' +
        '<label class="form-field"><span>任务方向分类</span><select class="filter" data-ro="1"><option>功能实现</option><option>用户体验</option><option>工程与构建</option></select></label>' +
        '<label class="form-field"><span>任务类型分类</span><select class="filter" data-ro="1"><option>新的需求</option><option>用户体验补充</option><option>bug修理</option></select></label>' +
        '<label class="form-field"><span>当前状态</span><select class="filter" data-ro="1"><option>未开始</option><option>执行中</option><option>已完成</option></select></label>' +
        '<label class="form-field"><span>优先级</span><select class="filter" data-ro="1"><option>高</option><option selected>中</option><option>低</option></select></label>' +
      '</div>' +
      '<div class="form-actions"><button class="btn primary" data-ro="1">确认新增</button><button class="btn btn-ghost" data-ro="1">清空</button></div>' +
    '</section>' +
  '</div>';
}

function createEditModal() {
  if (!state.editOpen) return '';
  return '<div class="modal-mask" id="preview-edit-modal">' +
    '<section class="modal-card modal-card--editor">' +
      '<header class="modal-head"><div><h2>编辑记录</h2><p class="hint">' + esc(state.editTitle || '当前记录') + '</p></div><button class="btn btn-ghost" type="button" id="close-edit" data-ro="1">关闭</button></header>' +
      '<dl class="detail-grid detail-grid--modal">' +
        '<dt>任务</dt><dd><input class="cell-input" data-ro="1" value="' + esc(state.editTitle || '示例任务') + '" /></dd>' +
        '<dt>方向</dt><dd><select class="filter" data-ro="1"><option>功能实现</option><option>用户体验</option></select></dd>' +
        '<dt>类型</dt><dd><select class="filter" data-ro="1"><option>新的需求</option><option>用户体验补充</option><option>bug修理</option></select></dd>' +
        '<dt>状态</dt><dd><select class="filter" data-ro="1"><option>未开始</option><option selected>执行中</option><option>已完成</option></select></dd>' +
        '<dt>优先级</dt><dd><select class="filter" data-ro="1"><option selected>高</option><option>中</option><option>低</option></select></dd>' +
        '<dt>描述</dt><dd><textarea class="cell-input" rows="4" data-ro="1">这里是浮窗编辑示例，真实页面会在这里修改当前记录的完整字段。</textarea></dd>' +
      '</dl>' +
    '</section>' +
  '</div>';
}

function tableBlock(title, hint, columns, rows, options = {}) {
  const tableRows = applySorts(rows, columns, options);
  const head = columns.map((col) => '<th' + (col.width ? ' style="width:' + col.width + '"' : '') + '>' + esc(col.label) + '</th>').join('');
  const body = tableRows.map((row) => '<tr class="data-row">' + columns.map((col) => {
    const value = typeof col.display === 'function' ? col.display(row) : join(row[col.key]);
    const className = col.numeric ? ' class="numeric"' : '';
    return '<td' + className + '><span class="' + toneFor(value) + '">' + esc(value) + '</span></td>';
  }).join('') + '<td class="action-col"><div class="action-buttons"><button class="btn btn-ghost" data-ro="1" data-edit-title="' + esc(row.title || row.id || row.path || '当前记录') + '">' + (options.editLabel || '编辑') + '</button>' + (options.withDelete ? '<button class="btn btn-danger" data-ro="1">删除</button>' : '') + '</div></td></tr>').join('');
  const sortControls = options.supportTaskSort
    ? '<div class="sort-group"><span class="sort-label">主排序</span><select class="filter" id="preview-primary-sort"><option value="">无</option>' +
        columns.map((col) => '<option value="' + esc(col.key) + '"' + (state.primarySortKey === col.key ? ' selected' : '') + '>' + esc(col.label) + '</option>').join('') +
      '</select><button class="btn btn-ghost sort-order-btn" type="button" id="preview-primary-order">' + (state.primarySortAsc ? '正序' : '倒序') + '</button></div>' +
      '<div class="sort-group"><span class="sort-label">次排序</span><select class="filter" id="preview-secondary-sort"><option value="">无</option>' +
        columns.filter((col) => col.key !== state.primarySortKey).map((col) => '<option value="' + esc(col.key) + '"' + (state.secondarySortKey === col.key ? ' selected' : '') + '>' + esc(col.label) + '</option>').join('') +
      '</select><button class="btn btn-ghost sort-order-btn" type="button" id="preview-secondary-order">' + (state.secondarySortAsc ? '正序' : '倒序') + '</button></div>' +
      '<button class="btn btn-ghost" type="button" id="preview-reset-sort">重置排序</button>'
    : '';
  return '<section class="table-block">' +
    '<header class="table-head"><div><h2>' + esc(title) + '</h2><p class="hint">' + esc(hint) + '</p></div>' +
      '<div class="table-tools"><input class="search" type="search" data-ro="1" placeholder="搜索…" /><button class="btn btn-ghost" data-ro="1">列</button>' + (options.supportHideCompleted ? '<button class="btn btn-ghost" type="button" id="toggle-completed" data-ro="1">' + (state.hideCompleted ? '显示已完成' : '隐藏已完成') + '</button>' : '') + sortControls + '</div></header>' +
    '<p class="row-count">共 ' + rows.length + ' 条' + (tableRows.length !== rows.length ? '，隐藏后 ' + tableRows.length + ' 条' : '') + '</p>' +
    '<div class="table-scroll"><table><thead><tr>' + head + '<th class="action-col">操作</th></tr></thead><tbody>' + body + '</tbody></table></div>' +
  '</section>';
}

function renderContent() {
  const summaryTaskRows = DATA.tasks.slice().sort((a, b) => a.order - b.order).map((item) => ({
    title: item.title,
    category: item.category,
    type: item.type,
    status: item.status,
    priority: item.priority,
    description: truncate(item.description, 56),
  }));
  const detailTaskRows = DATA.tasks.slice().sort((a, b) => a.order - b.order).map((item) => ({
    id: item.id,
    title: item.title,
    category: item.category,
    type: item.type,
    status: item.status,
    priority: item.priority,
    verify: item.verify,
    owner: item.owner || '—',
    blockedBy: item.blockedBy || '—',
    description: item.description || '—',
    dependsOn: item.dependsOn.length ? item.dependsOn.join('、') : '—',
    deliverables: item.deliverables.length ? item.deliverables.join('、') : '—',
    commits: item.commits.length ? item.commits.join('、') : '—',
    start: item.start || '—',
    done: item.done || '—',
    estimateDays: item.estimateDays,
    note: item.note || '—',
    source: item.source || '—',
  }));

  const taskSummaryTable = tableBlock(
    '任务汇总',
    '第一页主视图：默认列为方向 / 任务 / 类型 / 描述 / 状态 / 优先级。',
    [
      { key: 'category', label: '方向', width: '120px' },
      { key: 'title', label: '任务', width: '240px' },
      { key: 'type', label: '类型', width: '120px' },
      { key: 'description', label: '描述', width: '360px' },
      { key: 'status', label: '状态', width: '96px' },
      { key: 'priority', label: '优先级', width: '84px' },
    ],
    summaryTaskRows,
    { withDelete: true, editLabel: '编辑', supportHideCompleted: true, supportTaskSort: true },
  );

  const taskDetailTable = tableBlock(
    '任务扩容明细',
    '第二页与第一页是同一批任务；这里展示扩容字段与来源。',
    [
      { key: 'id', label: '编号', width: '86px' },
      { key: 'title', label: '任务', width: '220px' },
      { key: 'category', label: '方向', width: '120px' },
      { key: 'type', label: '类型', width: '120px' },
      { key: 'status', label: '状态', width: '96px' },
      { key: 'priority', label: '优先级', width: '84px' },
      { key: 'verify', label: '验证状态', width: '180px' },
      { key: 'owner', label: '负责人', width: '100px' },
      { key: 'blockedBy', label: '依赖/阻塞', width: '180px' },
      { key: 'description', label: '描述', width: '320px' },
      { key: 'dependsOn', label: '前置任务', width: '160px' },
      { key: 'deliverables', label: '交付物', width: '180px' },
      { key: 'commits', label: '提交', width: '160px' },
      { key: 'start', label: '开始', width: '108px' },
      { key: 'done', label: '完成', width: '108px' },
      { key: 'estimateDays', label: '预估(天)', width: '90px', numeric: true },
      { key: 'note', label: '备注', width: '220px' },
      { key: 'source', label: '来源', width: '220px' },
    ],
    detailTaskRows,
    { editLabel: '编辑', supportHideCompleted: true, supportTaskSort: true },
  );

  const pitfallsTable = tableBlock('关键坑', '第二页合并展示的一部分。', [
    { key: 'id', label: '#', width: '52px', numeric: true },
    { key: 'date', label: '日期', width: '104px' },
    { key: 'title', label: '标题', width: '220px' },
    { key: 'severity', label: '严重度', width: '80px' },
    { key: 'status', label: '状态', width: '92px' },
    { key: 'area', label: '区域', width: '140px' },
    { key: 'symptom', label: '现象', width: '260px' },
    { key: 'lesson', label: '教训', width: '260px' },
    { key: 'source', label: '出处', width: '160px' },
  ], DATA.pitfalls);

  const workspaceTable = tableBlock('工作区改动', '第二页合并展示的一部分。', [
    { key: 'path', label: '文件路径', width: '320px' },
    { key: 'kind', label: '类型', width: '80px' },
    { key: 'state', label: '状态', width: '86px' },
    { key: 'note', label: '备注', width: '260px' },
  ], DATA.workspace);

  const commitsTable = tableBlock('提交历史', '第二页合并展示的一部分。', [
    { key: 'hash', label: 'hash', width: '92px' },
    { key: 'date', label: '日期', width: '104px' },
    { key: 'type', label: '类型', width: '80px' },
    { key: 'message', label: '说明', width: '360px' },
  ], DATA.commits);

  $('#content').innerHTML = state.tab === 'summary'
    ? summaryBlock() + createActionBlock() + taskSummaryTable + createModal() + createEditModal()
    : '<div class="detail-stack">' + taskDetailTable + pitfallsTable + workspaceTable + commitsTable + '</div>' + createEditModal();

  const openButton = $('#open-create');
  if (openButton) {
    openButton.onclick = () => {
      state.createOpen = true;
      renderContent();
      toast('预览页只用于看样式，不写入数据。');
    };
  }
  const closeButton = $('#close-create');
  if (closeButton) {
    closeButton.onclick = () => {
      state.createOpen = false;
      renderContent();
    };
  }
  const modal = $('#preview-modal');
  if (modal) {
    modal.onclick = (event) => {
      if (event.target === modal) {
        state.createOpen = false;
        renderContent();
      }
    };
  }
  const toggleCompletedButton = $('#toggle-completed');
  if (toggleCompletedButton) {
    toggleCompletedButton.onclick = () => {
      state.hideCompleted = !state.hideCompleted;
      renderContent();
      toast(state.hideCompleted ? '预览中已隐藏已完成任务。' : '预览中已恢复显示已完成任务。');
    };
  }
  const primarySort = $('#preview-primary-sort');
  if (primarySort) {
    primarySort.onchange = (event) => {
      state.primarySortKey = event.target.value;
      if (state.secondarySortKey === state.primarySortKey) state.secondarySortKey = '';
      renderContent();
      toast('预览中已切换主排序。');
    };
  }
  const secondarySort = $('#preview-secondary-sort');
  if (secondarySort) {
    secondarySort.onchange = (event) => {
      state.secondarySortKey = event.target.value;
      renderContent();
      toast('预览中已切换次排序。');
    };
  }
  const primaryOrder = $('#preview-primary-order');
  if (primaryOrder) {
    primaryOrder.onclick = () => {
      state.primarySortAsc = !state.primarySortAsc;
      renderContent();
      toast('预览中已切换主排序方向。');
    };
  }
  const secondaryOrder = $('#preview-secondary-order');
  if (secondaryOrder) {
    secondaryOrder.onclick = () => {
      state.secondarySortAsc = !state.secondarySortAsc;
      renderContent();
      toast('预览中已切换次排序方向。');
    };
  }
  const resetSort = $('#preview-reset-sort');
  if (resetSort) {
    resetSort.onclick = () => {
      state.primarySortKey = 'status';
      state.primarySortAsc = true;
      state.secondarySortKey = 'priority';
      state.secondarySortAsc = true;
      renderContent();
      toast('预览中已恢复默认排序：状态 → 优先级。');
    };
  }
  document.querySelectorAll('[data-edit-title]').forEach((button) => {
    button.onclick = () => {
      state.editTitle = button.dataset.editTitle || '当前记录';
      state.editOpen = true;
      renderContent();
      toast('预览中已打开浮窗编辑示例。');
    };
  });

  document.querySelectorAll('[data-ro]').forEach((element) => {
    const previousClick = element.onclick;
    element.onclick = (event) => {
      if (typeof previousClick === 'function') previousClick(event);
      toast('预览页只用于看样式，不写入数据。');
    };
    element.onchange = () => toast('预览页只用于看样式，不写入数据。');
  });
}

$('#fake-edit').onclick = () => toast('预览页的编辑控件只为看样式；真实页面点这里会开启可写模式。');
$('#fake-refresh').onclick = () => toast('预览页数据是静态快照；真实页面点这里会重新拉取 /api/progress。');
$('#fake-theme').onclick = () => applyTheme(state.theme === 'dark' ? 'light' : 'dark');

applyTheme(state.theme);
renderTabs();
renderContent();
</script>
</body>
</html>`;

mkdirSync(path.dirname(outPath), { recursive: true });
writeFileSync(outPath, html, 'utf8');

const sizeKb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(1);
console.log(`✅ 已生成 ${path.relative(path.resolve(here, '..'), outPath)}（${sizeKb} KB）`);
console.log(`   数据快照：tasks ${doc.tasks.length} / pitfalls ${doc.pitfalls.length} / workspace ${doc.workspace.length} / commits ${doc.commits.length}`);
