/**
 * 预览页冒烟测试：验证 v2 两分页结构是否能正常渲染。
 */

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const htmlPath = path.resolve(here, 'style-preview.html');
const html = readFileSync(htmlPath, 'utf8');

const match = html.match(/<script>([\s\S]*?)<\/script>/);
if (!match) {
  console.error('❌ 没找到内联 <script>');
  process.exit(1);
}
const code = match[1];

class El {
  constructor(selector = '') {
    this.selector = selector;
    this._html = '';
    this.textContent = '';
    this.style = { display: '' };
    this.dataset = {};
    this.value = '';
    this.classList = { add() {}, remove() {}, toggle() {} };
    this.onclick = null;
    this.onchange = null;
  }
  set innerHTML(v) {
    this._html = String(v);
  }
  get innerHTML() {
    return this._html;
  }
}

const registry = new Map();
const el = (selector) => {
  if (!registry.has(selector)) registry.set(selector, new El(selector));
  return registry.get(selector);
};

const stubCache = new Map();
function makeStubs(attr, source) {
  const re = new RegExp(`${attr}="([^"]*)"`, 'g');
  const out = [];
  for (const matchItem of source.matchAll(re)) {
    const key = `${attr}:${matchItem[1]}`;
    if (!stubCache.has(key)) {
      const stub = new El(key);
      stub.dataset[attr.replace('data-', '')] = matchItem[1];
      stubCache.set(key, stub);
    }
    out.push(stubCache.get(key));
  }
  return out;
}

const document = {
  documentElement: { dataset: {} },
  querySelector: (selector) => el(selector),
  getElementById: (id) => el(`#${id}`),
  querySelectorAll: (selector) => {
    if (selector === '[data-tab]') return makeStubs('data-tab', el('#tabs').innerHTML);
    if (selector === '[data-ro]') return makeStubs('data-ro', el('#content').innerHTML);
    if (selector === '[data-edit-title]') return makeStubs('data-edit-title', el('#content').innerHTML);
    return [];
  },
};

const failures = [];
const check = (label, ok, detail = '') => {
  console.log(`${ok ? '✅' : '❌'} ${label}${detail ? ' — ' + detail : ''}`);
  if (!ok) failures.push(label);
};

try {
  // eslint-disable-next-line no-new-func
  new Function('document', 'setTimeout', 'clearTimeout', code)(document, setTimeout, clearTimeout);
  check('内联脚本执行无异常', true);
} catch (error) {
  check('内联脚本执行无异常', false, String(error && error.stack ? error.stack : error));
  process.exit(1);
}

const tabsHtml = el('#tabs').innerHTML;
const contentHtml = el('#content').innerHTML;

check('页签已渲染（2 个分页）', (tabsHtml.match(/data-tab="/g) || []).length === 2, `${(tabsHtml.match(/data-tab="/g) || []).length} 个`);
check('第一页已渲染统计区', contentHtml.includes('当前焦点') && contentHtml.includes('任务总数'));
check('第一页已渲染新增任务按钮', contentHtml.includes('id="open-create"') && contentHtml.includes('新增任务'));
check('第一页已渲染隐藏已完成按钮', contentHtml.includes('隐藏已完成'));
check('第一页已渲染双排序控件', contentHtml.includes('主排序') && contentHtml.includes('次排序') && contentHtml.includes('重置排序'));
check('第一页默认不显示新增任务表单', !contentHtml.includes('任务方向分类') && !contentHtml.includes('填写基础 6 字段后立即写入当前任务列表。'));
check('第一页任务汇总表有真实内容', contentHtml.includes('任务汇总') && contentHtml.includes('半自动锁定增强'));
check('第一页包含只读交互钩子', document.querySelectorAll('[data-ro]').length > 0, `${document.querySelectorAll('[data-ro]').length} 个`);

const detailTab = document.querySelectorAll('[data-tab]').find((item) => item.dataset.tab === 'details');
check('找到「全部明细」页签', Boolean(detailTab));
if (detailTab && typeof detailTab.onclick === 'function') {
  detailTab.onclick();
  const detailsHtml = el('#content').innerHTML;
  const rows = (detailsHtml.match(/class="data-row"/g) || []).length;
  check('切到全部明细后渲染四块表', detailsHtml.includes('任务扩容明细') && detailsHtml.includes('关键坑') && detailsHtml.includes('工作区改动') && detailsHtml.includes('提交历史'));
  check('全部明细有足够数据行', rows > 60, `${rows} 行`);
  check('任务扩容表含扩展字段', detailsHtml.includes('验证状态') && detailsHtml.includes('依赖/阻塞') && detailsHtml.includes('交付物'));
  check('关键坑与提交历史含真实内容', detailsHtml.includes('MeshCollider') && detailsHtml.includes('06730059'));
} else {
  check('「全部明细」页签可点击', false, 'onclick 未挂上');
}

console.log('');
if (failures.length === 0) {
  console.log('✅ 预览页冒烟测试通过：脚本可执行，v2 两分页与核心区块均正常生成。');
} else {
  console.log(`❌ ${failures.length} 项未通过：${failures.join('、')}`);
  process.exit(1);
}
